<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\User;
use Illuminate\Support\Facades\Hash;
class UserController extends Controller
{
    //
    public function register(Request $request){
        $request->validate([
            'name'=> 'string|required|min:3|max:15',
            'email'=>'string|required|email|unique:users',
            'password'=>'string|required|confirmed',
        ]);
        
        $user = new User();
        $user->name = $request->name;
        $user->email = $request->email;
        $user->password = bcrypt($request->password);
        $user->save();

        $token = $user->createToken('mytoken')->plainTextToken;
        
        $response = [
            'user' => $user,
            'token' => $token
        ];

        return response()->json($response);
    }

    public function login(Request $request){

        $request->validate([
            'email' => 'required|email',
            'password' => 'required',
        ]);
        // Check email 
        $user = User::where('email', $request->email)->first();
        
        // Check password
        if (!$user || !Hash::check($request->password, $user->password)) {
            return response('Login invalid', 503);
        }
        $token = $user->createToken('mytoken')->plainTextToken;
        
        $response = [
            'user' => $user,
            'token' => $token
        ];

        return response()->json($response);
    }

    public function logout(Request $request){
        $request()->user()->currentAccessToken()->delete();
        return response()->json(['message'=>'Logout successfully!']);
    }
}
